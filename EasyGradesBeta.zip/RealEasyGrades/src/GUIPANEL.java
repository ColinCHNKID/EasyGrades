import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
public class GUIPANEL extends JFrame implements ActionListener{
	private JPanel jp1,jp2,jp3; 
	private JButton buttonLogin;
	private JLabel labelUser,labelPasswd;
	private JPasswordField pfPasswd;
	private JTextField tfUser; 
	private JTextArea jtEnter; 
	int count=0; 
	public GUIPANEL()
	{
		 this.setSize(280,400);
         this.getContentPane().setLayout(null);
         add(setJButton(),null);         
         this.add(this.getJLabel1(),null);         
         labelUser.setText("用户名：");  
         this.add(this.getJLabel2(),null); 
         labelPasswd.setText("密码");          
         this.add(this.getJTextArea(), null);
         jtEnter.setText("");
         this.add(this.getJTextField(), null); 
         this.add(this.getJPW(), null); 
         int width = Toolkit.getDefaultToolkit().getScreenSize().width; 
         int height = Toolkit.getDefaultToolkit().getScreenSize().height;
         this.setLocation(width/2-200, height/2-150); 
		this.setVisible(true); 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public JButton setJButton()
    {
		buttonLogin = new JButton();
		buttonLogin.setBounds(82, 307, 100, 23);
		buttonLogin.setText("登录"); 
		buttonLogin.addActionListener(this);             
             return buttonLogin;
    }
	 public JLabel getJLabel1()
     {
		 labelUser = new JLabel();
		 labelUser.setBounds(82, 25, 112, 30);             
             return labelUser;
     }
	 public JLabel getJLabel2()
     {
		 labelPasswd = new JLabel();
		 labelPasswd.setBounds(82, 155, 112, 30);            
             return labelPasswd;
     }
	  private JTextArea getJTextArea()
      {
		  jtEnter = new JTextArea("txt");
		  jtEnter.setForeground(new Color(255,0,255));
		  jtEnter.setBounds(88, 285, 100, 20); 
		  jtEnter.setVisible(false);               
              return jtEnter; 
      }
	  private JTextField getJTextField()
      {
		  tfUser = new JTextField();
		  tfUser.setBounds(82, 80, 112, 50);              
              return tfUser;
      }
	  private JPasswordField getJPW()
	  {
		  pfPasswd = new JPasswordField(); 
		  pfPasswd.setBounds(82,210,112,50); 
		  return pfPasswd; 
	  }
	public void actionPerformed(ActionEvent e) {		
		if ((tfUser.getText().equals("sly"))&&(pfPasswd.getText().equals("123")))
		{
				jtEnter.setVisible(false);  
			this.setVisible(false); 
		}
		else
		{
			jtEnter.setVisible(true);
			jtEnter.append("用户名或密码错误！"); 
			count++; 
			if(count==5)
			{
				System.exit(0); //this.setVisible(false);  
			}  			
		} 
	}		
}