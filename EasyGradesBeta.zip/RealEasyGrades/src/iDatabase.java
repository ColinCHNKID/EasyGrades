import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class iDatabase 
{
	public XSSFWorkbook Database = new XSSFWorkbook();  
    public XSSFSheet sheet = Database.createSheet("StuScore");
	public XSSFFont font = Database.createFont();
	public XSSFCellStyle cst = Database.createCellStyle();
	public Row[] row = new Row[200];
    public XSSFRow headerRow = sheet.createRow(0);  
	public void Executive() throws IOException
	{
		font.setBold(true);
		font.setColor(XSSFFont.COLOR_NORMAL);
	    headerRow.setHeightInPoints(25f);
	    XSSFCell chNameHeader = headerRow.createCell(0);  
	    chNameHeader.setCellValue("CH Name");  
	    XSSFCell enNameHeader = headerRow.createCell(1);  
	    enNameHeader.setCellValue("EN Name");  
	    XSSFCell password = headerRow.createCell(2);
	    password.setCellValue("Password");  
	    for(int i = 1; i < 200; i++)
	    {
	    		row[i] = sheet.createRow(i);
	    }
	    FileOutputStream fileOut = new FileOutputStream("StuScore.xlsx"); 
	    Database.write(fileOut);  
	    fileOut.close();  
	}
}