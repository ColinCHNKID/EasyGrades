import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;  
import java.util.List;  
import org.apache.poi.hssf.usermodel.HSSFWorkbook;  
import org.apache.poi.ss.usermodel.Cell; 
import org.apache.poi.ss.usermodel.Row;  
import org.apache.poi.ss.usermodel.Sheet;  
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;  
import org.apache.poi.xssf.util.*;
public class RealEasyGrades 
{
	static int count = 2;
	public static void actionForUploading(String Filepath, String subject, iDatabase Database)
	{
		count++;
		StoreStuScores Subject = new StoreStuScores();
		Subject.storeStuScore(Filepath);
		Cell sub = Database.headerRow.createCell(count);
		sub.setCellValue(subject);
        for(int i = 1; i < Subject.getNam().size(); i++)
        {
        		Cell name = Database.row[i].createCell(0);
        		name = (Subject.getNam().get(i-1));
        }
        for(int i = 1; i < Subject.getSco().size(); i++)
        {
        		Cell name = Database.row[i].createCell(count);
        		name = (Subject.getSco().get(i-1));
        }
	}
	public static void main(String[] args)  throws Exception
	{
		iDatabase Database = new iDatabase();
		Database.Executive();
		actionForUploading("/Users/apple/eclipse-workspace/RealEasyGrades/Bio.xlsx", "Biology", Database);
		actionForUploading("/Users/apple/eclipse-workspace/RealEasyGrades/HG.xlsx", "Human Geo", Database);
		actionForUploading("/Users/apple/eclipse-workspace/RealEasyGrades/CS.xlsx", "Computer Sci", Database);
		GUIPANEL a = new GUIPANEL();
	}
}