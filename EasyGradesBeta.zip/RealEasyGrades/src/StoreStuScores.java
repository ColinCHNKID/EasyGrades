import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class StoreStuScores
{
	private  ArrayList<Cell> singleScore = new ArrayList<Cell>();
	private  ArrayList<Cell> singleName  = new ArrayList<Cell>();
	private  String subject;
	private  Sheet sheet;
	private  Row Frow;
	private  Row[] row;
	private  Cell cell;
	private  int nameCol;
	private  int finalCol;
	private  int i;
	private  Workbook wb;
	public void storeStuScore(String Filepath) 
	{
		try 
		{
			File file = new File(Filepath);
			InputStream is = new FileInputStream(file.getAbsolutePath());  
			wb = new XSSFWorkbook(is);
			sheet = wb.getSheetAt(0);
			Frow = sheet.getRow(0);
			for(i = 0; i <= 50; i++) 
			{
				cell = Frow.getCell(i);
				if(cell.getStringCellValue().equals("Name")) 
				{
					break;
				}
			}
			nameCol = i;
			for(i = 0; i <= 50; i++) 
			{
				cell = Frow.getCell(i);
				if(cell.getStringCellValue().equals("score")) 
				{
					break;
				}
			}
			finalCol = i;
			row = new Row[200];
			for(i = 0; i < 200; i++) 
			{
				if(!(row[i].getCell(nameCol).equals(""))) 
				{
					singleScore.add(row[i].getCell(finalCol));
					singleName.add(row[i].getCell(nameCol));
				}
				else
					break;
			}
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	public ArrayList<Cell> getSco() 
	{
		return singleScore;
	}
	public ArrayList<Cell> getNam() 
	{
		return singleName;
	}
	public int getNameCol() 
	{
		return nameCol;
	}
	public int getFinalCol() 
	{
		return finalCol;
	}
}